/*
 * Serverless function to handle booking enquiries.
 *
 * This function expects a POST request with a JSON body containing
 * { name: string, email: string, message: string } and uses nodemailer
 * to send the details to a designated receiver email. Configure the
 * sender credentials and receiver address via environment variables
 * as follows when deploying on Vercel:
 *
 *   EMAIL_USERNAME   – the SMTP username (e.g. Gmail address)
 *   EMAIL_PASSWORD   – the SMTP password or app password
 *   RECEIVER_EMAIL   – the address where enquiries should be delivered
 *
 * When running locally without dependencies installed, the send
 * operation will be skipped and the data will simply be logged.
 */

const nodemailer = require('nodemailer');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).send('Method Not Allowed');
    return;
  }
  // Read request body
  let body = '';
  await new Promise((resolve, reject) => {
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', resolve);
    req.on('error', reject);
  });
  let data;
  try {
    data = JSON.parse(body);
  } catch (err) {
    res.status(400).send('Invalid JSON body');
    return;
  }
  const { name, email, phone, checkIn, checkOut, guests, message } = data;
  // Validate required fields. All fields are mandatory for a complete booking enquiry.
  if (!name || !email || !phone || !checkIn || !checkOut || !guests || !message) {
    res.status(400).send('Missing required fields');
    return;
  }
  // Attempt to send email via nodemailer if credentials are provided
  const user = process.env.EMAIL_USERNAME;
  const pass = process.env.EMAIL_PASSWORD;
  const receiver = process.env.RECEIVER_EMAIL || user;
  if (user && pass) {
    try {
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: { user, pass }
      });
      await transporter.sendMail({
        from: user,
        to: receiver,
        subject: 'New Booking Enquiry – La Casa Maite',
        text: `Name: ${name}\nEmail: ${email}\nPhone: ${phone}\nCheck‑in: ${checkIn}\nCheck‑out: ${checkOut}\nGuests: ${guests}\nMessage: ${message}`
      });
      res.status(200).json({ status: 'sent' });
    } catch (error) {
      console.error('Email sending failed:', error);
      res.status(500).json({ error: 'Failed to send email' });
    }
  } else {
    // If no credentials are provided, just log the data and respond success
    console.log('Booking enquiry received:', { name, email, phone, checkIn, checkOut, guests, message });
    res.status(200).json({ status: 'received', message: 'No email credentials configured' });
  }
};